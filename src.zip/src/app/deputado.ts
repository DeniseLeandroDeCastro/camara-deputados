export class Deputado {

          id: number;
        nome: string;
       email: string;
     siglaUF: string;
     urlFoto: string;

}
